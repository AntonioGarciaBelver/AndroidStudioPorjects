package com.example.ud5cp2

class Comunidad(var nombre: String, var imagen: Int=0) {
    override fun toString(): String {
        return nombre
    }
}