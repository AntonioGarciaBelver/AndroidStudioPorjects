package models

class Fruta(var nombre:String, var descripcion:String, var imagen: Int, var cantidad: Int) {
}