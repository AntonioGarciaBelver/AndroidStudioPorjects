package com.example.ud2_cp2

class Cuenta(var numeroCuenta:String, var propietario: Persona?){

    constructor():this("",null )

    var saldo: Double = 0.0
        set(value) {
            if (value >= 0){
                field = value
            }
        }get() = field

    fun transaccion( cantidad:Double, tipoTransaccion:String):Double{
        if(tipoTransaccion == "reintegro"){
            if(cantidad >saldo){
                saldo = 0.0
            }
            saldo -= cantidad
        }else if(tipoTransaccion == "ingreso"){
            saldo += cantidad
        }
        return saldo
    }

    override fun toString(): String {
        return "$propietario " +
                "\nNumero Cuenta: $numeroCuenta" +
                "\nSaldo: $saldo" +
                "\n-------------------------------"
    }


}