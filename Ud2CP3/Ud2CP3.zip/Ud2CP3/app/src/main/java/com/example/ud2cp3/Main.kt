package com.example.ud2cp3

fun main(){

    var p1 = ProductoFresco("03/01/2022", "01/12/2022",1234567,"Spain")

    var p2 = ProductoRefrigerado("01/12/2022",1234567,"127FFG")

    var p3 = ProductoCongelado("01/12/2024",1234567,-35.5)

    println(p1)
    println(p2)
    println(p3)

}